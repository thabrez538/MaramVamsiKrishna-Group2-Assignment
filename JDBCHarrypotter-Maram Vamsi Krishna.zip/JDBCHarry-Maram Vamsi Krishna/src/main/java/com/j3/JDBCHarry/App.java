package com.j3.JDBCHarry;

import java.sql.Statement;
import java.util.jar.Attributes.Name;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws ClassNotFoundException, SQLException
    {
    	
    	Class.forName("com.mysql.cj.jdbc.Driver");
    	System.out.println("Loaded Driver");
  	
    	Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/harry","root","Vamsi@123");
    	System.out.println("Connection Establised");
    	
    	Statement st=c.createStatement();
    	c.setAutoCommit(false);
    	String[] insertStatements= {
    	"insert into harrypotter values('Ginny Weasley','Gryffindor','Student','Friend','No')",
    	"insert into harrypotter values('Ron Weasley','Gryffindor','Student','Friend','No')",
    	"insert into harrypotter values('Hermione Granger','Gryffindor','Student','Friend','No')",
    	"insert into harrypotter values('Neville Longbottom','Gryffindor','Student','Friend','No')",
    	"insert into harrypotter values('Oliver wood','Gryffindor','Student','Friend','No')",
    	"insert into harrypotter values('Luna Lovegood','RavenClaw','Student','Friend','No')",
    	"insert into harrypotter values('Cho Chang','RavenClaw','Student','Friend','No')",
    	"insert into harrypotter values('Cedric Diggory','Hufflepuff','Student','Friend','Yes')",
    	"insert into harrypotter values('Hannah Abott','Hufflepuff','Student','Friend','No')",
    	"insert into harrypotter values('Draco Malfoy','Slytherin','Student','Enemy','No')",
    	"insert into harrypotter values('Vincent Crabbe','Slytherin','Student','Enemy','Yes')",
    	"insert into harrypotter values('Gregory Goyle','Slytherin','Student','Enemy','No')",
    	"insert into harrypotter values('Penelope Clearwater','Slytherin','Student','Enemy','No')",
    	"insert into harrypotter values('Albus Dumbledore','Gryffindor','Faculty','Friend','Yes')",
    	"insert into harrypotter values('Severus Snape','Slytherin','Faculty','Enemy','Yes')",
    	"insert into harrypotter values('Remus Lupin','Gryffindor','Faculty','Friend','Yes')",
    	"insert into harrypotter values('Horace Slughorn','Slytherin','Faculty','Friend','No')",
    	"insert into harrypotter values('Rubeus Hagrid','Gryffindor','Faculty','Friend','No')",
    	"insert into harrypotter values('Minerva McGonagall','Gryffindor','Faculty','Friend','No')",
    	"insert into harrypotter values('James Potter','Gryffindor','Student','Family','Yes')",
    	"insert into harrypotter values('Sirius Black','Gryffindor','Student','Friend','Yes')",
    	"insert into harrypotter values('Lily Potter','Gryffindor','Student','Family','Yes')",
    	"insert into harrypotter values('Peter Pettigrew','Gryffindor','Student','Enemy','Yes')",
    	"insert into harrypotter values('Tom Morvolo Riddle','Slytherin','Student','Enemy','Yes')",
    	};
    	
    	try(PreparedStatement batchStatement=c.prepareStatement("insert into harrypotter values(?,?,?,?,?)"))
    			{
    				for (String insertStatement:insertStatements) {
    					batchStatement.addBatch(insertStatement);
    				}
    				//batchStatement.executeBatch();
    				c.commit();
    			}
    	try(PreparedStatement batchStatement=c.prepareStatement("select * from harrypotter")){
    		ResultSet res=batchStatement.executeQuery();
    		while(res.next()) {
    			System.out.println(res.getString(1)+"\t\t"+res.getString(2)+"\t\t"+res.getString(3)+"\t\t"+res.getString(4)+"\t\t"+res.getString(5));
    		}
    	}
    	
    	String query="select Name from harrypotter where house='Gryffindor'";
    	try(PreparedStatement ps=c.prepareStatement(query)){
    		ResultSet res=ps.executeQuery();
    		System.out.println("Names of the characters who belong to house Gryffindor:");
    		while(res.next()) {
    			
    			System.out.println(res.getString(1));
    		}
    	}
    	
    	String query2="select House,Name,Role,Status from harrypotter where Dies='No' group by House,Name,Role,Status";
    	try(PreparedStatement p=c.prepareStatement(query2)){
    		ResultSet r=p.executeQuery();
    		System.out.println("Details of the characters whose status is alive and grouped by houses:");
    		while(r.next()) {
    			
    			System.out.println(r.getString(1)+"\t\t"+r.getString(2)+"\t\t"+r.getString(3)+"\t\t"+r.getString(4));
    		}
    	}
    	
    	String query3="select * from harrypotter where Status='Family'";
    	try(PreparedStatement p=c.prepareStatement(query3)){
    		ResultSet r=p.executeQuery();
    		System.out.println("Details of Harry potter family members");
    		while(r.next()) {
    			
    			System.out.println(r.getString(1)+"\t\t"+r.getString(2)+"\t\t"+r.getString(3)+"\t\t"+r.getString(4)+"\t\t"+r.getString(5));
    		}
    	}
    			
    	
    	catch(SQLException e) {
    		e.printStackTrace();
    	}
    	
    	
    	
    	
    	
    	
    	
    }
}
